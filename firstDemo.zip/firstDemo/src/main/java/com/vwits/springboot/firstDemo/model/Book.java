package com.vwits.springboot.firstDemo.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Book {
	@Id
	private int bookId;
	private String bookName;
	private String bookAuthor;

	public Book() {
		System.out.println("Book bean created...");
	}
	
	public Book(int bookId, String bookName, String authorName) {
		super();
		this.bookName = bookName;
		this.bookId = bookId;
		this.bookAuthor = authorName;
		
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	
	
	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}

	@Override
	public String toString() {
		return "Book [bookName=" + bookName + ", bookId=" + bookId + ", bookAuthor=" + bookAuthor + "]";
	}

	@Override
	public boolean equals(Object obj) {
		return ((Book)obj).bookId == this.bookId;
	}


}
