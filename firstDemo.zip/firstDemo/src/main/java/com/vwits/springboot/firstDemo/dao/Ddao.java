package com.vwits.springboot.firstDemo.dao;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vwits.springboot.firstDemo.model.Book;

public interface Ddao extends JpaRepository<Book,Integer>{
	public Optional<Book> findBybookName(String bookName);
	
	public Optional<Book>findBybookId(int bookId);
	@Transactional
	public Optional<Boolean> removeBybookId(int bookId);
}
