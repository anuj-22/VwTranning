package com.vwits.springboot.firstDemo.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.vwits.springboot.firstDemo.model.Book;

@Service
public class BookDao {
	@Autowired
	private Ddao dao;
	//List<Book> bookArr;

	public BookDao() {
		/*
		 * bookArr = new ArrayList<Book>();
		 * 
		 * bookArr.add(new Book(1, "Rich Dad & Poor Dad", "Rober T.Kyosaki"));
		 * bookArr.add(new Book(2, "The Psychology Of Money", "Morgan Housel"));
		 * bookArr.add(new Book(3, "Gulliver's Travel", "Jonathan Swift"));
		 */
	}

	public boolean addBook(Book b) {
		dao.save(b);
		return true;
	}

	public List<Book> getBook(String bookName) {
		/*
		 * Book book = bookArr.stream().filter((b) -> { return b.getBookId() == bookId;
		 * }).findFirst().orElse(null); System.out.println(book);
		 */
		 List<Book> b = dao.findBybookName(bookName);
		 System.out.println("BookFounds" +b.size());
		 for(Book bo : b) {
			 System.out.println(bo);
		 }
		 return dao.findBybookName(bookName);
	}

	public Book getBook1(int bookId) {
		/*
		 * Optional<Book> book = bookArr.stream().filter((b) -> { return b.getBookId()
		 * == bookId; }).findFirst();
		 * 
		 * if (book.isPresent()) return book.get(); else
		 */
			return  dao.getById(bookId);
	}

	public Book getBook2(int bookId) {
		/*
		 * Iterator<Book> itr = bookArr.iterator(); Book b1 = null;
		 * 
		 * while (itr.hasNext()) { b1 = itr.next(); if (b1.getBookId() == bookId) {
		 * return b1; } }
		 */
		return null;

	}

	public void  removeBook(Book b) {
		/*
		 * boolean status = this.bookArr.remove(b); if (status) return b.getBookId();
		 * else return -1;
		 */
		return;
		
	}

	public Book removeBook(int bookId) {
		/*
		 * boolean status = this.bookArr.removeIf(b -> b.getBookId() == bookId);
		 * if(status) return bookId; else return -1;
		 */
		Book t=dao.getOne(bookId);
		dao.delete(t);
		return t;
	}

	public List<Book> getAllBooks() {
		return dao.findAll();
	}

	public Book updateCourse(Book book) {
		/*
		 * Iterator<Book> itr = bookArr.iterator(); ((Iterable<Book>) itr).forEach(e->{
		 * if(e.getBookId()==b.getBookId()) { e.setBookName(b.getBookName());
		 * e.setBookAuthor(b.getBookAuthor()); } });
		 * System.out.println("Book list updated "); return b;
			*/
		dao.save(book);
		return book;
	}

}
