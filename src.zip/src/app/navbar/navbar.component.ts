import { HttpResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/Book';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  //bookarr: Book[];
  bookdao: BookdaoService;
  book:Book;
  bookIdValue:any;

  constructor(bookdao: BookdaoService) {
    this.book=new Book(0, '', '');
   // this.bookarr = [];
    this.bookdao = bookdao;
    this.bookIdValue = undefined;
    
  }
  ngOnInit(): void {
    /*this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );*/
  }
 
  getBookByname(form:any) {
    this.bookdao.getBookByName(this.bookIdValue).subscribe(

      (data: Book) => {
        console.log(data);
        this.book = data;
      }
    )  }
     
      getBook(id: Number) {
        console.log();
        this.bookdao.getBook(id).subscribe(
          (data: Book) => {
            console.log(data);
            this.book = data;
            
          },
          (error) => {
            console.log(error);
          }
        )
      }
  
}

