import { Component, OnInit } from '@angular/core';
import { ActivatedRoute ,Router} from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/Book';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit{
  bookId: Number;
  book: Book;
  bookdao: BookdaoService;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    bookdao: BookdaoService) 
    {
      this.bookId = 0;
      this.book = new Book(0, '', '');
      this.bookdao = bookdao;
  }
  ngOnInit(): void {
    this.route
    .queryParams
    .subscribe(params => {
      console.log(params); // { order: "popular" }
      this.bookId = params['bookId'];
      console.log(this.bookId); // popular
    }
  );
}
  

  updateform(form: any) {
    this.bookdao.updateBook(this.bookId, this.book).subscribe({
      complete: () => { console.log('updateBook put completed..') }, // completeHandler
      error: (error) => { console.log(error) },    // errorHandler
      next: (response) => { console.log('book updated successfully') }
    });

    this.router.navigate(['/listBooks']);

    // console.log('book form submitted');
    // console.log(this.book);
    // // this.bookdao.addBook(this.book);

    // this.bookdao.updateBook(this.book).subscribe(
    //   {
    //     complete: () => { console.log('updated post completed..') }, // completeHandler
    //     error: (error: any) => { console.log(error) },    // errorHandler
    //     next: (response) => { console.log('book updated successfully') }
    //   })
      
    }

}
