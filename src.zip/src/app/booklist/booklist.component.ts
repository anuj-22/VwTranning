import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/Book';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {

  bookarr: Book[];
  bookdao: BookdaoService;
 

  constructor(bookdao: BookdaoService, private router:Router) {
    this.bookarr = [];
    this.bookdao = bookdao;
    
  }

  ngOnInit(): void {
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    );
    
  }

  deleteBook(id: number) {
    console.log('delete called');
    this.bookdao.deleteBook(id).subscribe(() => this.ngOnInit());
  }

  updateBook(id: number) {
    console.log(`edit called ${id}`);
    this.router.navigate(['/updateBook'], {queryParams: {bookId: id}});
  }
  getAllBooks()
  {
    this.bookdao.getAllBooks().subscribe(
      (data: Book[]) => {
        console.log(data);
        this.bookarr = data;
      }
    )
  }
}
