import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookformComponent } from './bookform/bookform.component';
import { BooklistComponent } from './booklist/booklist.component';
import { CreateComponent } from './create/create.component';
import { UpdateComponent } from './update/update.component';

const routes: Routes = [
  {
    path: 'addBook',
    component: BookformComponent
  },
  /*{
    path: '',
    redirectTo: 'addBook',
    pathMatch: 'full'
  },*/
  {
    path: 'listBooks',
    component: BooklistComponent
  },
  {path:'search',
  component:CreateComponent
  },
  {
    path:'updateBook',

    component:UpdateComponent,
    // pathMatch:'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
