
export class Book
{
    bookId:number;
    bookName:string;
    bookAuthor:string;


    constructor(bookid:number,bookname:string,bookauthor:string)
    {
        this.bookId = bookid;
        this.bookName = bookname;
        this.bookAuthor = bookauthor;

    }

    getBook():string
    {
        return 'bookid:'+this.bookId +","
               +'bookName:'+this.bookName+","
               +'bookauthor:'+this.bookAuthor;
    }


}